import tkinter as tk
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2Tk
import numpy as np

#Main Variable
Constant_T1 = 10 # Same for Boyle's Law
Constant_T2 = 3
PV_Constant = 10
VT_Constant = 290
PT_Constant = 290
Global_Board = 0
Main_Graph_Color = "r"
Supporting_Graph_Color = "k"

def Clear_Frame(Frame):
    # Assuming there is only canvas in the Frame
    for Canvas in Frame.winfo_children():
        Canvas.destroy()


def Plot_Boyle(Frame):
    Clear_Frame(Frame)

    # Creates a Figure Canvas to Plot Graphs
    Graph_Fig = plt.Figure(figsize=(7.5, 5.5), dpi=100)
    Plotter = Graph_Fig.add_subplot(111)
    Board = FigureCanvasTkAgg(Graph_Fig, master=Frame)
    Board.get_tk_widget().grid(row=2, column=0)
    Plotter.set_xlabel('Volume / m\u00B3')
    Plotter.set_ylabel('Pressure / kPa')

    # Plotting of curve to represent Constant Temperature
    V_T1 = np.arange(0.8,12,0.01)
    P_T1 = Constant_T1/V_T1
    V_T2 = np.arange(0.25,12,0.01)
    P_T2 = Constant_T2/V_T2
    Plotter.plot(V_T1,P_T1, linestyle=":", label="Temperature 1 (T1)", color= Supporting_Graph_Color)
    Plotter.plot(V_T2, P_T2, linestyle="--", label="Temperature 2 (T2)", color=Supporting_Graph_Color)

    # Plotting of Boyle's Law
    V = np.arange(1, 10, 0.01)
    P = PV_Constant / V
    Plotter.plot(V, P, label="T1 > T2\nBoyle\'s Law", color=Main_Graph_Color)

    # Plotter area modification
    Plotter.grid(True)
    Plotter.legend()

def Plot_Charles(Frame):
    Clear_Frame(Frame)

    # Creates a Figure Canvas to Plot Graphs
    Graph_Fig = plt.Figure(figsize=(7.5, 5.5), dpi=100)
    Plotter = Graph_Fig.add_subplot(111)
    Board = FigureCanvasTkAgg(Graph_Fig, master=Frame)
    Board.get_tk_widget().grid(row=2, column=0)
    Plotter.set_xlabel('Volume / m\u00B3')
    Plotter.set_ylabel('Pressure / kPa')

    # Plotting Charle's Law Graph
    V = np.arange(1, 13, 1)
    P = V//V
    Plotter.plot(V,P, label="Charle\'s Law", color=Main_Graph_Color)
    Plotter.set_xlim([0,13])
    Plotter.set_ylim([0,13])

    # Plotter area modification
    Plotter.grid(True)
    Plotter.legend()

def Plot_Const_Volume(Frame):
    Clear_Frame(Frame)

    # Creates a Figure Canvas to Plot Graphs
    Graph_Fig = plt.Figure(figsize=(7.5, 5.5), dpi=100)
    Plotter = Graph_Fig.add_subplot(111)
    Board = FigureCanvasTkAgg(Graph_Fig, master=Frame)
    Board.get_tk_widget().grid(row=2, column=0)
    Plotter.set_xlabel('Volume / m\u00B3')
    Plotter.set_ylabel('Pressure / kPa')

    # Plotting Constant Volume Graph
    P = np.arange(1, 13, 1)
    V = P // P
    Plotter.plot(V, P, label="Constant Volume Law", color=Main_Graph_Color)
    Plotter.set_xlim([0,13])
    Plotter.set_ylim([0,13])


    # Plotter area modification
    Plotter.grid(True)
    Plotter.legend()
