# Have 5 main functions
# These are: Create layout, Animation for ball, Animation for Pressure,
#            Animation for Volume and Animation for Temperature

import tkinter as tk
import random as rand
import math
import Interactive_Mode_Page as IMP

# This will be the main variables at hand

# Mutable Variables
Font_Type = "Arial" # Changes font type of Gauge Meter 
Font_Size = 9 # Changes font size of Gauge Meter
Radius_of_Gauge_Meter = 80 # Changes size of Gauge Meter
Radius_of_Holder_Circle = 5
Length_of_Main_Points = 15
Length_of_Label_Points = 13
Centre = (90,250) # Changes position of Gauge Meter
Diameter_of_Ball = 20 # Changes size of the Bouncing Balls
Num_of_Ball = 10 # Changes number of Balls displayed
Ball_Colour = "#d4f9d2"
Thickness_of_Small_Rect = 15
Thickness_of_Big_Rect = 20
Base_Frame_Per_Animation = 3
Base_Delay_Time = 120
Length_of_Outer_Hexagon = 80 # changes size of hexagon
Outer_Top_Left = (665, 100) # change position of hexagon
Outer_Hexagon_Colour = "black"
Inner_Hexagon_Colour = "orange"
Hexagon_Type_of_Font = "OCR A Extended"
Hexagon_Font_Size = "25"
Hexagon_Font_Colour = "black"
Hexagon_Unit = "K"

#Constant Variables
Radian_per_Degree = math.pi/180
Half_Done = False
Ball_List = []
Fixed_Movement = 3
Left_Border = 180
Right_Border = 580
Max_Top_Border = 25
Bottom_Border = 500
Base_Top_Border = 450
Base_Angle = 45
Angle_per_times = 30
Length_of_Blank_Space = 30
Radius_of_Readings_Circle = Radius_of_Gauge_Meter - Length_of_Blank_Space
Radius_of_Main_Points_Circle = Radius_of_Readings_Circle - Length_of_Main_Points
Radius_of_Label_Points_Circle = Radius_of_Readings_Circle + Length_of_Label_Points
Length_of_Mid_Points = math.floor(Length_of_Main_Points/2)
Radius_of_Mid_Points_Circle = Radius_of_Readings_Circle - Length_of_Mid_Points
Small_Rect_Xcoords = (Left_Border + 150, Right_Border - 150)
Big_Rect_Xcoords = (Left_Border, Right_Border)
Total_Thickness = Thickness_of_Small_Rect + Thickness_of_Big_Rect


# Variables used in calculations
Angle_per_Pressure = 30
TopBorder_per_MeterCube = 45
Temp_per_Frame = 290
Temp_per_Delay = 29
Length_of_Inner_Hexagon = Length_of_Outer_Hexagon - 10
Internal_Angle = 120
Theta = 120 - 90
Outer_Height = Length_of_Outer_Hexagon * math.cos(math.pi / 180 * Theta)
Outer_Distance = Length_of_Outer_Hexagon * math.sin(math.pi / 180 * Theta)
Inner_Height = Length_of_Inner_Hexagon * math.cos(math.pi / 180 * Theta)
Inner_Distance = Length_of_Inner_Hexagon * math.sin(math.pi / 180 * Theta)
Difference_Length = Outer_Distance - Inner_Distance
Difference_Height = Outer_Height - Inner_Height
Inner_Top_Left = (Outer_Top_Left[0] + Difference_Length, Outer_Top_Left[1] + Difference_Height)

# Variables That will be changed during animation
Pointer = 0 # Not the address one, the arrow one
Top_Border = 450
Small_Rect = 0
Big_Rect = 0
Frame_Per_Animation = 1
Delay_Time = 100
X_Move = []
Y_Move = []
Hexagon_Display=0
Ongoing_Animation = True


# Convenience Functions
def Stop_Animation():
    global Ongoing_Animation
    Ongoing_Animation = False

def Start_Animation():
    global Ongoing_Animation
    Ongoing_Animation = True


# Main Functions
def Reset():
    global Top_Border
    global Ball_List
    global Small_Rect
    global Big_Rect
    global Half_Done
    global Pointer
    global Frame_Per_Animation
    global Delay_Time
    global X_Move
    global Y_Move
    global Hexagon_Display
    global Ongoing_Animation

    Top_Border = Base_Top_Border
    Ball_List = []
    Small_Rect = 0
    Big_Rect = 0
    Half_Done = False
    Pointer = 0
    Frame_Per_Animation = Base_Frame_Per_Animation
    Delay_Time = Base_Delay_Time
    X_Move = []
    Y_Move = []
    Hexagon_Display=0
    Ongoing_Animation = True


def Canvas_Layout(Canvas):
    # Creates the layout of the entire animation
    # Resets all the variables that might have been modified previously
    global Ball_List
    global Small_Rect
    global Big_Rect
    global Half_Done
    global Pointer
    global X_Move
    global Y_Move
    global Hexagon_Display

    Reset()

    # Generate Ball according to the wanted amount
    for Times in range(Num_of_Ball):
        Left_X_Coord = rand.randint(Left_Border, Right_Border - 2*Diameter_of_Ball)
        Left_Y_Coord = rand.randint(Base_Top_Border, Bottom_Border-2*Diameter_of_Ball)
        Ball = Canvas.create_oval(Left_X_Coord,Left_Y_Coord,
                                  Left_X_Coord+Diameter_of_Ball, Left_Y_Coord+Diameter_of_Ball, fill=Ball_Colour)
        Ball_List.append(Ball)

    # Generates A list of Movements
    def Random_Bool():
        num = rand.randint(0, 1)
        if num == 0: return False
        return True

    for times in range(Num_of_Ball):
        num = rand.randint(Fixed_Movement - 2, Fixed_Movement + 2)
        if Random_Bool():
            X_Move.append(num)
        else:
            X_Move.append(-num)
        num = rand.randint(Fixed_Movement - 2, Fixed_Movement + 2)
        if Random_Bool():
            Y_Move.append(num)
        else:
            Y_Move.append(-num)

 

    # Piston Creations
    Small_Rect = Canvas.create_rectangle(Small_Rect_Xcoords[0], Base_Top_Border - Total_Thickness,
                                         Small_Rect_Xcoords[1], Base_Top_Border - Thickness_of_Big_Rect, outline='Black', fill='black')
    Big_Rect = Canvas.create_rectangle(Big_Rect_Xcoords[0], Base_Top_Border - Thickness_of_Big_Rect,
                                       Big_Rect_Xcoords[1], Base_Top_Border, outline='Black', fill='black')

    # Container Creation
    Canvas.create_line(Left_Border, Max_Top_Border, Left_Border, Bottom_Border, fill='black', width=2) # Left Line
    Canvas.create_line(Right_Border, Max_Top_Border, Right_Border, Bottom_Border, fill='black', width=2) # Right Line
    Canvas.create_line(Left_Border, Bottom_Border, Right_Border, Bottom_Border, fill='black', width=2) # Bottom Line


    # Gauge Meter Creation
    def Get_Y(Degree, Radius):
        # Uses Trigonometry to find Y
        Y = Centre[1] + round(Radius * math.cos(Radian_per_Degree * Degree))
        return Y

    def Get_X(Y, Radius):
        # Uses the equation of the circle to obtain X
        X = -math.sqrt(Radius ** 2 - (Y - Centre[1]) ** 2) + Centre[0]
        if Half_Done:
            X = math.sqrt(Radius ** 2 - (Y - Centre[1]) ** 2) + Centre[0]
        return X

    # Gauge meter's body
    Canvas.create_oval(Centre[0] - Radius_of_Gauge_Meter, Centre[1] - Radius_of_Gauge_Meter,
                      Centre[0] + Radius_of_Gauge_Meter, Centre[1] + Radius_of_Gauge_Meter,fill='White')

    # Holder of the arrow in Gauge meter
    Canvas.create_oval(Centre[0] - Radius_of_Holder_Circle, Centre[1] - Radius_of_Holder_Circle,
                      Centre[0] + Radius_of_Holder_Circle, Centre[1] + Radius_of_Holder_Circle, fill="red")

    # Arc that Displays the readings
    Canvas.create_arc(Centre[0] - Radius_of_Readings_Circle, Centre[1] - Radius_of_Readings_Circle,
                     Centre[0] + Radius_of_Readings_Circle, Centre[1] + Radius_of_Readings_Circle,
                     start=315, extent=270, style=tk.ARC, outline="red")

    # Pointer for starting position and Label of Gauge meter
    Reading_Reference_Y = Get_Y(Base_Angle, Radius_of_Readings_Circle)
    Reading_Reference_X = Get_X(Reading_Reference_Y, Radius_of_Readings_Circle)
    Pointer = Canvas.create_line(Reading_Reference_X, Reading_Reference_Y, Centre[0], Centre[1], arrow=tk.FIRST, width=3)
    tk.Label(Canvas, text="Pressure\nkPa",bg='white').place(x=Centre[0]-23, y=Centre[1]+37)

    # Creates the lines in the Gauge meter
    for times in range(10):
        # Uses the idea of 2 circles to obtain the coordinates

        # Main Points plotting
        Main_Point_Degree = Base_Angle + (Angle_per_times * times)
        if times == 5: Half_Done = True
        Y1 = Get_Y(Main_Point_Degree, Radius_of_Readings_Circle)
        X1 = Get_X(Y1, Radius_of_Readings_Circle)
        Y2 = Get_Y(Main_Point_Degree, Radius_of_Main_Points_Circle)
        X2 = Get_X(Y2, Radius_of_Main_Points_Circle)
        Canvas.create_line(X1, Y1, X2, Y2, fill="red")

        # Label Plotting
        Y = Get_Y(Main_Point_Degree, Radius_of_Label_Points_Circle)
        X = Get_X(Y, Radius_of_Label_Points_Circle)
        tk.Label(Canvas, text=str(times + 1), font=(Font_Type, Font_Size),bg='white').place(x=X - 5, y=Y - 12)

        # Mid Points Plotting
        if times >= 9: continue
        Mid_Point_Degree = Base_Angle + (Angle_per_times / 2) + (Angle_per_times * times)
        Y3 = Get_Y(Mid_Point_Degree, Radius_of_Readings_Circle)
        X3 = Get_X(Y3, Radius_of_Readings_Circle)
        Y4 = Get_Y(Mid_Point_Degree, Radius_of_Mid_Points_Circle)
        X4 = Get_X(Y4, Radius_of_Mid_Points_Circle)
        Canvas.create_line(X3, Y3, X4, Y4, fill="red")

        #pipe creation
        Canvas.create_line(70,320,70,495,fill='black',smooth=True)
        Canvas.create_line(70,495,180,495,fill='black',smooth=True)
        Canvas.create_line(105,320,105,460,fill='black',smooth=True)
        Canvas.create_line(105,460,180,460,fill='black',smooth=True)

        #fill for pipe
        Canvas.create_rectangle(72,325,105,495, fill='#bebebe',width=0)
        Canvas.create_rectangle(72,495,180,463, fill='#bebebe',width=0)

        #dark red part for gaugemeter
        Canvas.create_line(137,235,143,275,120,287, fill='red',width='5',smooth=1)
        

        # Temperature Hexagon Display
    List_of_Outer_Coords = [Outer_Top_Left,
                            (Outer_Top_Left[0] + Length_of_Outer_Hexagon, Outer_Top_Left[1]),
                            (Outer_Top_Left[0] + Length_of_Outer_Hexagon + Outer_Distance,
                             Outer_Top_Left[1] + Outer_Height),
                            (Outer_Top_Left[0] + Length_of_Outer_Hexagon, Outer_Top_Left[1] + 2 * Outer_Height),
                            (Outer_Top_Left[0], Outer_Top_Left[1] + 2 * Outer_Height),  # Bottom
                            (Outer_Top_Left[0] - Outer_Distance, Outer_Top_Left[1] + Outer_Height),
                            ]
    List_of_Inner_Coords = [Inner_Top_Left,
                            (Inner_Top_Left[0] + Length_of_Inner_Hexagon, Inner_Top_Left[1]),
                            (Inner_Top_Left[0] + Length_of_Inner_Hexagon + Inner_Distance,
                             Inner_Top_Left[1] + Inner_Height),
                            (Inner_Top_Left[0] + Length_of_Inner_Hexagon, Inner_Top_Left[1] + 2 * Inner_Height),
                            (Inner_Top_Left[0], Inner_Top_Left[1] + 2 * Inner_Height),  # Bottom
                            (Inner_Top_Left[0] - Inner_Distance, Inner_Top_Left[1] + Inner_Height),
                            ]

    Canvas.create_polygon(List_of_Outer_Coords, fill=Outer_Hexagon_Colour)
    Canvas.create_polygon(List_of_Inner_Coords, fill=Inner_Hexagon_Colour)
    Hexagon_Display = Canvas.create_text(Inner_Top_Left[0] + Inner_Distance, Inner_Top_Left[1] + Inner_Height,
                      text=str(IMP.T_Min)+"K", font=(Hexagon_Type_of_Font, Hexagon_Font_Size), fill=Hexagon_Font_Colour)
    
    #Holder for Hexagon Thermometer
    Canvas.create_line (640,185,580,185, fill="Black", smooth=True)
    Canvas.create_line (640,150,580,150, fill="Black", smooth=True)
    Canvas.create_polygon (580,185,640,185,625,169,640,150,580,150)



def Animation_For_Ball(Root, Canvas):
    # Deals solely on the aspect of Ball Animation
    # Two main parts, which are ensuring the balls are within the
    # canvas and to create the animation for ball


    # Ensure that the ball is within Border and (collision)
    def Border_Checks():
        # Ensure that the Ball is within border
        # Changes the direction of movement when ball touches the border
        # Top Border is more unique and will be dealt with in another function

        global X_Move
        global Y_Move
        for Index in range(len(Ball_List)):
            Ball = Ball_List[Index]
            Ball_Coords = Canvas.coords(Ball)

            if Ball_Coords[0] <= Left_Border or Ball_Coords[2] >= Right_Border:
                X_Move[Index] = -X_Move[Index]
            if Ball_Coords[3] >= Bottom_Border:
                Y_Move[Index] = -Y_Move[Index]

    def Top_Border_Checks():
        # Instead of just changing direction of movement, it also creates
        # a new ball everytime they escape the border

        global Ball_List
        global Y_Move
        for Index in range(len(Ball_List)):
            Ball = Ball_List[Index]
            Ball_Coords = Canvas.coords(Ball)
            if Ball_Coords[1] <= Top_Border:
                Canvas.delete(Ball)
                Ball_List[Index] = Canvas.create_oval(Ball_Coords[0], Top_Border + 2,
                                                            Ball_Coords[2], Top_Border + Diameter_of_Ball + 2, fill=Ball_Colour)
                Y_Move[Index] = -Y_Move[Index]


    def Ball_Checks():
        Top_Border_Checks()
        Border_Checks()
       


    # Ball movements
    def Move_All_Balls():
        # Deletes the old Ball
        # Creates a new ball by a pre-determined distance
        # Replaces the old ball with the newly created ball in the list

        global Ball_List
        for Index in range(Num_of_Ball):
            Ball = Ball_List[Index]
            Ball_Coords = Canvas.coords(Ball)
            Canvas.delete(Ball)
            Movement = [X_Move[Index], Y_Move[Index]]
            Ball_List[Index] = Canvas.create_oval(Ball_Coords[0] + Movement[0], Ball_Coords[1] + Movement[1],
                                            Ball_Coords[2] + Movement[0], Ball_Coords[3] + Movement[1], fill=Ball_Colour)  # Adds new Ball
            Canvas.update()


    # Overall Code for Checking and Animating of ball
    def Ball_Animation():
        if Ongoing_Animation:
            for Frame in range(Frame_Per_Animation):
                Move_All_Balls()
                Ball_Checks()
        Root.after(Delay_Time, Ball_Animation)


    Ball_Animation()

def Pressure_Animation(Canvas, Change_in_Pressure):
    # Command function for Pressure Scale.
    # Deletes and creates a new Arrow when the Pressure is modified.
    # Y-Coordinate is found using geometry and the knowledge that the starting
    # point of the Arc is 45 degree away from the vertical line cutting the centre.
    # Uses the Circle Equation "(X-X1)^2 + (Y-Y1)^2 = R^2" to determine
    # the X-Coordinate.

    global Pointer

    def Get_Y(Degree):
        Y = Centre[1] + round(Radius_of_Readings_Circle * math.cos(Radian_per_Degree * Degree))
        return Y

    def Get_X(Y):
        X = -math.sqrt(Radius_of_Readings_Circle ** 2 - (Y - Centre[1]) ** 2) + Centre[0]
        if Angle>=193:
            X = math.sqrt(Radius_of_Readings_Circle ** 2 - (Y - Centre[1]) ** 2) + Centre[0]
        return X

    Additional_Angle = Change_in_Pressure * Angle_per_Pressure
    Angle = Base_Angle + Additional_Angle
    Y = Get_Y(Angle)
    X = Get_X(Y)
    Canvas.delete(Pointer)
    Pointer = Canvas.create_line(X, Y, Centre[0], Centre[1], arrow=tk.FIRST, width=3)


def Volume_Animation(Canvas, Change_in_Volume):
    # Command function for Volume Scale
    # Modifies the Top Border and also deletes and create the piston
    # everytime the volume is change

    global Top_Border

    def Animate_Piston():
        global Small_Rect
        global Big_Rect
        Canvas.delete(Small_Rect)
        Canvas.delete(Big_Rect)

        Small_Rect = Canvas.create_rectangle(Small_Rect_Xcoords[0], Top_Border - Total_Thickness,
                                             Small_Rect_Xcoords[1], Top_Border - Thickness_of_Big_Rect,
                                             outline='Black', fill='black')
        Big_Rect = Canvas.create_rectangle(Big_Rect_Xcoords[0], Top_Border - Thickness_of_Big_Rect,
                                           Big_Rect_Xcoords[1], Top_Border, outline='Black', fill='black')

    Change_in_Border = Change_in_Volume * TopBorder_per_MeterCube
    Top_Border = int(math.floor(Base_Top_Border - Change_in_Border))
    Animate_Piston()


def Temperature_Animation(Canvas, Change_in_Temp):
    # Command function for Temperature scale
    # Changes the Delay time and Frame per animation
    global Frame_Per_Animation
    global Delay_Time

    def Change_Display(string):
        global Hexagon_Display
        Canvas.delete(Hexagon_Display)
        Hexagon_Display = Canvas.create_text(Inner_Top_Left[0] + Inner_Distance, Inner_Top_Left[1] + Inner_Height,
                      text=(str(string)+"K"), font=(Hexagon_Type_of_Font, Hexagon_Font_Size), fill=Hexagon_Font_Colour)

    Change_Display(int(Change_in_Temp + IMP.T_Min))
    Change_in_Delay = int(math.floor(Change_in_Temp / Temp_per_Delay))
    Delay_Time = Base_Delay_Time - Change_in_Delay
    Change_in_Frame = int(math.floor(Change_in_Temp / Temp_per_Frame))
    Frame_Per_Animation = Base_Frame_Per_Animation + Change_in_Frame



# Variables that is constant
Length_of_Line = 700
Width_of_Line = 50
Pixels_per_Animation = 10
Top_Left_Line_Coord = (135,20)
Progress_Colour = "green"


# Variable that is dependant on the mutable variables
Radius_of_Arc = Width_of_Line
Border_Increase_per_Question = Length_of_Line/5
Progress_Bar_Final_X = Top_Left_Line_Coord[0] + Length_of_Line

# Variables that changes while application is running
First = True
Progress_Bar = 0
Continue_Animation = False
Border_of_Progress = Top_Left_Line_Coord[0]
Progress_Bar_Right_X = Top_Left_Line_Coord[0]
Finish = False


def Increase_Border():
    global Border_of_Progress
    Border_of_Progress += Border_Increase_per_Question

def Reset_Progress():
    global First
    global Progress_Bar
    global Continue_Animation
    global Border_of_Progress
    global Progress_Bar_Right_X
    global Finish

    First = True
    Progress_Bar = 0
    Continue_Animation = False
    Border_of_Progress = Top_Left_Line_Coord[0]
    Progress_Bar_Right_X = Top_Left_Line_Coord[0]
    Finish = False

def Progress_Layout(Board):
    global Progress_Bar
    Reset_Progress()

    # Progress Bar
    Board.create_line(Top_Left_Line_Coord[0], Top_Left_Line_Coord[1],
                      Top_Left_Line_Coord[0] + Length_of_Line, Top_Left_Line_Coord[1])
    Board.create_line(Top_Left_Line_Coord[0], Top_Left_Line_Coord[1] + Width_of_Line,
                      Top_Left_Line_Coord[0] + Length_of_Line, Top_Left_Line_Coord[1] + Width_of_Line)

    Board.create_arc(Top_Left_Line_Coord[0] - Radius_of_Arc / 2, Top_Left_Line_Coord[1],
                     Top_Left_Line_Coord[0] + Radius_of_Arc / 2, Top_Left_Line_Coord[1] + Width_of_Line, start=90,
                     extent=180, style=tk.ARC)
    Board.create_arc(Top_Left_Line_Coord[0] + Length_of_Line + Radius_of_Arc / 2, Top_Left_Line_Coord[1],
                     Top_Left_Line_Coord[0] + Length_of_Line - Radius_of_Arc / 2,
                     Top_Left_Line_Coord[1] + Width_of_Line, start=90, extent=-180, style=tk.ARC)

    Progress_Bar = Board.create_rectangle(Top_Left_Line_Coord[0], Top_Left_Line_Coord[1],
                                          Progress_Bar_Right_X, Top_Left_Line_Coord[1] + Width_of_Line, width=0)

def Progress_Bar_Animation(Root, Board):

    def Start_Progress():
        global First
        Board.create_arc(Top_Left_Line_Coord[0] - Radius_of_Arc / 2, Top_Left_Line_Coord[1],
                Top_Left_Line_Coord[0] + Radius_of_Arc / 2, Top_Left_Line_Coord[1] + Width_of_Line, start=90,
                extent=180, fill=Progress_Colour, width=0, outline = Progress_Colour)
        First = False

    def End_Progress():
        global Finish
        Board.create_arc(Top_Left_Line_Coord[0] + Length_of_Line + Radius_of_Arc / 2, Top_Left_Line_Coord[1],
                         Top_Left_Line_Coord[0] + Length_of_Line - Radius_of_Arc / 2,
                         Top_Left_Line_Coord[1] + Width_of_Line, start=90, extent=-180, fill = Progress_Colour, width=0, outline = Progress_Colour)
        Finish = True

    def Animate_Progress_Bar():
        global Progress_Bar
        global Progress_Bar_Right_X

        if First: Start_Progress()

        Progress_Bar_Right_X += Pixels_per_Animation
        Board.delete(Progress_Bar)
        Progress_Bar = Board.create_rectangle(Top_Left_Line_Coord[0], Top_Left_Line_Coord[1] + 1,
                                              Progress_Bar_Right_X, Top_Left_Line_Coord[1] + Width_of_Line, fill=Progress_Colour, width=0)
        
        if Progress_Bar_Right_X >= Progress_Bar_Final_X: End_Progress()

    def Check_Reach_Border():
        global Continue_Animation
        if Progress_Bar_Right_X >= Border_of_Progress: Continue_Animation = False
        else: Continue_Animation = True

    def Animation():
        if Finish: return

        if Continue_Animation: Animate_Progress_Bar()
        Check_Reach_Border()
        Root.after(100, Animation)


    Animation()

