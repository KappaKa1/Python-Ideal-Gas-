# Will always remain regardless of which page the application is at
# Main purpose is to create a pathway to reach other pages

import tkinter as tk
import Interactive_Mode_Page as IMP
import Graphs_Page as GP
import Quiz_Page as QP
from tkinter import messagebox

# Main Variable
Frame_List = []
Help_Title = "Main Menu Help"
Help_Message = "Just click any button To start"
Interactive_Open = False # Change
Graph_Open = False # Change
Quiz_Open = False # Change



def Main_Menu(Main_Window):
    # Creates the main menu of the application
    # Main menu consist of Buttons to access the different pages and also a Help button

    # Local Variable
    Button_List = []


    def Pop_Up_Help(value=0):
        messagebox.showinfo(Help_Title, Help_Message)
        Help_Pic.configure(file='qb.gif')

    def Change_Help(Title, Message):
        global Help_Title
        global Help_Message
        Help_Title = Title
        Help_Message = Message

    def Reset_Main_Menu():
        Inter_Button.config(state=tk.NORMAL)
        Graphs_Button.config(state=tk.NORMAL)
        Quiz_Button.config(state=tk.NORMAL)

    def Clear_Page():
        for Frames in Frame_List:
            Frames.grid_forget()
            Frames.destroy()  # It also removes the Frame from the list

    def Reset_Open(): # Change
        global Interactive_Open # Change
        global Graph_Open # Change
        global Quiz_Open # Change
        Interactive_Open = False # Change
        Graph_Open = False # Change
        Quiz_Open = False # Change
        IMP.Close_Interactive() # Change
        GP.Close_Graph() # Change
        QP.Close_Quiz() # Change

    def Reset_Page():
        # Resets the whole window
        Clear_Page() # Change
        Reset_Main_Menu() # Change
        Reset_Open() # Change


    # Call-back Functions
    # Each of these function when called will Reset the whole window, Change the
    # contents of help button, Create its own page layout, disable its button
    # and finally stores the Frames used
    def Call_Interactive_Mode(value=0): # Change
        global Frame_List
        global Interactive_Open # Change

        if Interactive_Open: return # Change

        Reset_Page()
        Interactive_Open = True # Change
        Change_Help(IMP.Get_Help_Title(), IMP.Get_Help_Message())
        IMP.Interactive_Mode_Design(Main_Window)
        Inter_Button.config(state= tk.DISABLED)
        Frame_List = IMP.Get_Frame_List()


    def Call_Graphs(value=0): # Change
        global Frame_List
        global Graph_Open # Change

        if Graph_Open: return # Change

        Reset_Page()
        Graph_Open = True # Change
        Change_Help(GP.Get_Help_Title(), GP.Get_Help_Message())
        GP.Graphs_Design(Main_Window)
        Graphs_Button.config(state= tk.DISABLED)
        Frame_List = GP.Get_Frame_List()


    def Call_Quiz(value=0): 
        global Frame_List
        global Quiz_Open 
        if Quiz_Open: return 

        Reset_Page()
        Quiz_Open = True 
        Change_Help(QP.Get_Help_Title(), QP.Get_Help_Message())
        QP.Quiz_Design(Main_Window)
        Quiz_Button.config(state= tk.DISABLED)
        Frame_List = QP.Get_Frame_List()


    # Design of Main Menu
    Top_Frame = tk.Frame(Main_Window, highlightbackground='black', highlightthickness=2)
    Top_Frame.place(x=270,y=10)
    Inter_Button = tk.Button(Top_Frame, text="Interactive Mode",fg="white", command=Call_Interactive_Mode, width= 20,
                             bg="#4163CE",activebackground= "#4163CE", font= ("Georgia", 12, 'bold'),disabledforeground="#C0C0C0")
    Inter_Button.pack(side=tk.LEFT)
    Main_Window.bind("<Control-Key-1>", Call_Interactive_Mode) 
    Graphs_Button = tk.Button(Top_Frame, text="Graphs",fg="white", command=Call_Graphs, width=10,
                              bg="#4163CE",activebackground= "#4163CE", font= ("Georgia", 12, 'bold' ),disabledforeground="#C0C0C0")
    Graphs_Button.pack(side=tk.LEFT)
    Main_Window.bind("<Control-Key-2>", Call_Graphs) 
    Quiz_Button = tk.Button(Top_Frame, text="Quiz", fg="white", command=Call_Quiz, width=10,
                            bg="#4163CE", activebackground= "#4163CE", font= ("Georgia", 12, 'bold'),disabledforeground="#C0C0C0")
    Quiz_Button.pack(side=tk.LEFT)
    Main_Window.bind("<Control-Key-3>", Call_Quiz) 

    Help_Pic=tk.PhotoImage(file='qb.gif')
    
    # Help Button Section
    Top_Left_Frame = tk.Frame(Main_Window,bd=0,highlightthickness=0, bg='#cae6f2')
    Top_Left_Frame.place (x=900, y=0,)
    Help_Button = tk.Button(Top_Left_Frame, image=Help_Pic, command=Pop_Up_Help)
    Help_Button.pack()
    Help_Label= tk.Label(Top_Left_Frame,text="HELP",bg='#cae6f2', font=("Georgia", 10))
    Help_Label.pack()

    # Binding of Keys # Change
    Main_Window.bind("<Key-h>", Pop_Up_Help) # Change

    Call_Interactive_Mode() # Change
