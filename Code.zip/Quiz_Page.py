# Universal Variable and Function
Frame_List = []
Help_Title = "Quiz Help"
Help_Message = "Welcome to the Quiz Help.\nTo use the Quiz page:\n1. Click on an option from the " \
               "4 choices provided to make it your answer.\n2.  Click on that option again " \
               "to deselect option.\n3.  To submit your answer, press the submit button.\nP.S. The submit button " \
               "will not work without an answer selected.\n"\
               "\n- Press CTRL + 1 for Interactive Mode Page \n- Press CTRL + 2 for Graph Page"\
               "\n- Press CTRL + 3 for Quiz Page"\
               "\n\n- Press 'H' Key for HELP \n- Press 'T' Key for TIP \n- Press 'Enter' to SUBMIT."
def Get_Frame_List(): return Frame_List
def Get_Help_Title(): return Help_Title
def Get_Help_Message(): return Help_Message


import tkinter as tk
import Questions_And_Answers as QAA
from tkinter import messagebox
import Animation as Ani

# Main Variables

# Variables that can be changed'
Hint_Title= "This is a big hint..."
Correct_Submission_Title = "Congrats"
Correct_Submission_Content = "Well done!\nYour answer is correct!"
Wrong_Submission_Title = "Oh no!"
Wrong_Submission_Content = "Please try harder...\nYour answer is incorrect"
Error_Title = "Error"
Error_Message_for_No_Selection = "Please select one option before submitting"
Error_Message_for_Too_Much_Selection = "Please do not select more than 1 option when submitting"

# Variables that is constant
Unticked_Char = 0
Number_of_Question = len(QAA.Question_List)

# Variable that will be only used once
First = True

# Variables that changes while application is running
Quiz_Open = False
Question_Number = 0
Submission_Title = ""
Submission_Content = ""

def Close_Quiz():
    global Quiz_Open
    Quiz_Open = False

def Reset():
    global Question_Number
    global Quiz_Open

    Question_Number = 0
    Quiz_Open = True


def Quiz_Design(main):
    global Frame_List
    global First # Change

    Reset() # Change

    # Local Variables
    Checklist_List = []
    Option_String_List = []
    Option_Number_List = []

    # Functions that will be used in the call-back function

    # Error Prevention Functions
    def End_of_Quiz():
        if Question_Number >= Number_of_Question :
            Display_Message("That's All!", "This is the end of quiz, ")
            return True

    def Choice_Error():
        # Ensures that there is only 1 choice selected
        # If not error message will pop up
        Number_of_Unticked = 0
        for Int_Var in Option_Number_List:
            Number = Int_Var.get()
            if Number == Unticked_Char: Number_of_Unticked += 1

        if Number_of_Unticked == 3:
            return False
        elif Number_of_Unticked == 4:
            Display_Message(Error_Title, Error_Message_for_No_Selection)
            return True
        else:
            Display_Message(Error_Title, Error_Message_for_Too_Much_Selection)
            return True

    # Answer Checking
    def Obtain_Answer():
        # All unchecked option will return value of Unticked_Char
        for Int_Var in Option_Number_List:
            if Int_Var.get() != Unticked_Char: return Int_Var.get()

    def Check_Answer(Answer):
        # Checks the Answer is right or wrong
        # Change the display of message
        global Submission_Title
        global Submission_Content
        if Answer == QAA.Answer_List[Question_Number]:
            Submission_Title = Correct_Submission_Title
            Submission_Content = Correct_Submission_Content
        else:
            Submission_Title = Wrong_Submission_Title
            Submission_Content = Wrong_Submission_Content + QAA.Solutions_List[Question_Number]

    def Display_Message(Title, Content):
        messagebox.showinfo(Title, Content)

    def Show_Result():
        Answer = Obtain_Answer()
        Check_Answer(Answer)
        Display_Message(Submission_Title, Submission_Content)

    # Changing of Questions
    def Update_Question_Number():
        global Question_Number
        if Question_Number >= Number_of_Question: return
        Question_Number += 1

    def Update_Question():
        # Changes the question displayed
        Question_Content.set(QAA.Question_List[Question_Number])

    def Update_Checklist():
        # changes the answers displayed
        for Index in range(len(Option_String_List)):
            Option_String_List[Index].set(QAA.MCQ_Choices_List[Question_Number][Index])

    def Reset_Checklist():
        for Checklist in Checklist_List:
            Checklist.deselect()

    def Restart_Quiz():
        End_of_Quiz()
        Reset()
        Board.delete("all")
        Ani.Progress_Layout(Board)
        Ani.Progress_Bar_Animation(main, Board)
        
    def Change_Question():
        Update_Question()
        Reset_Checklist()
        Update_Checklist()



    # Call-Back Function
    def Submission(value=0):
        if not Quiz_Open: return
        if Choice_Error(): return

        Ani.Increase_Border()
        Show_Result()
        Update_Question_Number()
        if Question_Number >= Number_of_Question:
            Restart_Quiz()
        Change_Question()

    def Popup_Hint(value=0):
        if not Quiz_Open: return
        global Question_Number
        messagebox.showinfo(Hint_Title, QAA.Hint_List[Question_Number])
        hint_img.configure(file='hintbutton.gif')


    # Question Statement Design
    hint_img=tk.PhotoImage(file="hintbutton.gif")
    Hint_Frame=tk.Frame(main, bd=0,highlightthickness=0, bg='#cae6f2')
    Hint_Frame.place(x=1000,y=80)
    Hint_Button= tk.Button(Hint_Frame,image=hint_img, highlightbackground= "black", command=Popup_Hint)
    Hint_Button.pack()
    Hint_Label=tk.Label(Hint_Frame,text="TIP",bg='#cae6f2', font=("Georgia", 10))
    Hint_Label.pack()
    Question_Frame = tk.Frame(main,borderwidth=2,relief='solid')
    Question_Frame.place (x= 135, y=80)
    Question_Frame.pack_propagate(True)
    Question_Content = tk.StringVar(value = QAA.Question_List[Question_Number])
    Question_Label = tk.Label(Question_Frame, textvariable=Question_Content, font= ("Georgia",13), bg="white", padx=20)
    Question_Label.pack()


    # MCQ Design
    Answer_Choice_Frame = tk.Frame(main,bg="#cae6f2") 
    Answer_Choice_Frame.place (x= 145, y= 210)
    First_Choice_Number = tk.IntVar()
    First_Choice_String = tk.StringVar(value = QAA.MCQ_Choices_List[Question_Number][0])
    First_Choice = tk.Checkbutton(Answer_Choice_Frame, variable=First_Choice_Number,
                                  textvariable=First_Choice_String, onvalue=1, font=("Georgia",14)
                                  ,bg="#cae6f2", pady=5, activebackground="#cae6f2")
    First_Choice.pack()
    Second_Choice_Number = tk.IntVar()
    Second_Choice_String = tk.StringVar(value=QAA.MCQ_Choices_List[Question_Number][1])
    Second_Choice = tk.Checkbutton(Answer_Choice_Frame, variable=Second_Choice_Number,
                                   textvariable=Second_Choice_String, onvalue=2, font=("Georgia",14)
                                   ,bg="#cae6f2", pady=5, activebackground="#cae6f2")
    

    Second_Choice.pack()
    Third_Choice_Number = tk.IntVar()
    Third_Choice_String = tk.StringVar(value=QAA.MCQ_Choices_List[Question_Number][2])
    Third_Choice = tk.Checkbutton(Answer_Choice_Frame, variable=Third_Choice_Number,
                                  textvariable=Third_Choice_String, onvalue=3, font=("Georgia",14)
                                  ,bg="#cae6f2", pady=5, activebackground="#cae6f2")
    Third_Choice.pack()
    Fourth_Choice_Number = tk.IntVar()
    Fourth_Choice_String = tk.StringVar(value=QAA.MCQ_Choices_List[Question_Number][3])
    Fourth_Choice = tk.Checkbutton(Answer_Choice_Frame, variable=Fourth_Choice_Number,
                                   textvariable=Fourth_Choice_String, onvalue=4, font=("Georgia",14)
                                   ,bg="#cae6f2", pady=5, activebackground="#cae6f2")
    Fourth_Choice.pack()

    # Submit Button Design
    Submit_Button_Frame = tk.Frame(main)
    Submit_Button_Frame.place (x= 890, y=300)
    Submit_Button = tk.Button(Submit_Button_Frame,text='Submit', command=Submission
                              , padx= 10, pady= 7, highlightbackground= "black", font=("Georgia",12)
                              , bg="#c9cbf1", activebackground="#c9cbf1")
    Submit_Button.pack()

    # Store Widgets and variable used
    Checklist_List = [First_Choice, Second_Choice, Third_Choice, Fourth_Choice]
    Option_String_List = [First_Choice_String, Second_Choice_String,
                          Third_Choice_String, Fourth_Choice_String]
    Option_Number_List = [First_Choice_Number, Second_Choice_Number,
                          Third_Choice_Number, Fourth_Choice_Number]

    # Progress Bar
    Progress_Bar_Frame = tk.Frame(main)
    Progress_Bar_Frame.place(x=10, y=600 - Ani.Width_of_Line - 10)
    Board = tk.Canvas(Progress_Bar_Frame, height=600, width=1100, bg='#cae6f2', bd=0,highlightthickness=0)
    Board.pack()
    Ani.Progress_Layout(Board)
    Ani.Progress_Bar_Animation(main, Board)

    # Key Binding
    main.bind("<Return>", Submission)
    main.bind("<Key-t>", Popup_Hint)

    # Store all the Frames used
    Frame_List = [Question_Frame, Answer_Choice_Frame, Submit_Button_Frame,Hint_Frame, Progress_Bar_Frame]

    # Introduction
    if First:  # Change
        messagebox.showinfo(Help_Title, Help_Message)
        First = False
