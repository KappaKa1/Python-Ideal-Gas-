Question_List = [''' 
1) A piston initially has a volume of 1m\u00B3 but Jack pushed the piston down with a pressure that reduces 
the volume of the piston to a quarter its initial volume. What is the pressure that Jack exerted if
the initial pressure within the piston is 10 kPa?
''',
                 '''
2) A rigid container full of air is at a pressure of 100kPa and a temperature of 283K. The temperature in the
container is raised to and maintained at 373K. What is the new pressure in the container?

''',
                 '''
3) Oxygen gas having a volume of 1.0 litre at 313K expands at constant pressure until its volume is 1.5 litres.
Find the final temperature of the oxygen.

''',
                 '''
4) A bicycle tyre has a volume of 0.12 m\u00B3 when fully inflated. If temperature does not change, what is the
volume needed to inflate a completely flat tyre with a pressure of 100kPa to a total pressure of 300kPa?

''',
                 '''
5) For a pressure cooker with a volume of 10 litre, Mandy raised the temperature inside from 350K to 600K.
What is the new pressure inside the pressure cooker if its initial pressure is 200kPa?

'''
]

# Number return for each choice 1st: 1, 2nd: 2, 3rd: 3, 4th: 4. 0 is option not selected
Answer_List = [1, 1, 3, 4, 2] # The answer will be in numbers to represent which choice is correct

MCQ_Choices_List = [("4.0 x 10\u2074 Pa", "4.0 x 10\u2075 Pa", "2.5 x 10\u00B3 Pa", "2.5 x 10\u2074 Pa"),
                    ("1.32 x 10\u2075 Pa", "1.47 x  10\u00B9 Pa", "1.32 x 10\u2074 Pa", "1.05 x 10\u2070 Pa"),
                    ("469.50 K", "470.00 K", "234.75 K", "900.00 K"),
                    ("4.00 m\u00B3", "2.77 m\u00B3", "3.60 m\u00B3", "0.04 m\u00B3"),
                    ("0.090 kPa", "343.0 kPa", "117.0 kPa", "0.017 kPa")] # It will be tuple in a list
Solutions_List=['''\n\n
Step 1: Identify variable given by the question,\n
\tV\u2081 = 1 m\u00B3, V\u2082 = 0.25 m\u00B3, P\u2081 = 10,000 Pa
\t(1 kPa = 1000 Pa)

Step 2: Identify formula to use given pressure and volume,\n
\tP\u2081V\u2081 = P\u2082V\u2082

Step 3: Substitute values into formula;\n
\t10,000(1) = P\u2082(0.25)

\t0.25P\u2082 = 10,000

\tP\u2082 = 40,000 Pa''',
                '''\n\n
Step 1: Identify variable given by the question,\n
\tP\u2081 = 1 x 10\u2075 Pa, T\u2081 = 283 K, T\u2082 = 373 K

Step 2: Identify formula to use given pressure and temperature,\n
\tP\u2081/T\u2081 = P\u2082/T\u2082

Step 3: Substitute values into formula;\n
\t(1 x 10\u2075) / 283 =P\u2082 / (373)

\t1 x 10\u2075(373) = 283(P\u2082)

\tP\u2082 = 1.32 x 10\u2075 Pa ''',
                '''\n\n
Step 1: Identify variable given by the question,\n
\tV\u2081 = 1 litre, V\u2082 = 1.5 litre, T\u2081 = 313 K

Step 2: Identify formula to use given temperature and volume,\n
\tV\u2081/T\u2081 = V\u2082/T\u2082

Step 3: Substitute values into formula;\n
\t2/313 = 1.5 / T\u2082

\t2(T\u2082) = 1.5(313)

\tT\u2082 = 234.75 K ''',
                '''\n\n
Step 1: Identify variable given by the question,\n
\tP\u2081 = 1 x 10\u2075 Pa, P2 = 3 x 10\u2075 Pa, V\u2082 = 0.12 m\u00B3

Step 2: Identify formula to use given pressure and volume,\n
\tP\u2081V\u2081 = P\u2082V\u2082

Step 3: Substitute values into formula;\n
\t1 x 10\u2075(0.12) = (3 x 10\u2075)V\u2082

\t(3x10\u2075)V\u2082 = 12,000

\tV\u2082 = 0.04 m\u00B3''',
                '''\n\n
Step 1: Identify variable given by the question,\n
\tP\u2081 = 200,000 Pa, T\u2081 = 350 K, T\u2082 = 600 K, V = 10 litre

Step 2: Identify formula to use at constant volume given pressure and temperature,\n
\tP\u2081/T\u2081 = P\u2082/T\u2082

Step 3: Substitute values into formula;\n
\t(2 x 10\u2075) / 350 = P\u2082 / (600)

\t120 x 10\u2076 = 350P\u2082

\tP\u2082 = 3.43 x 10\u2075 Pa ''']

Hint_List= ['''
Use formula below:
\nP\u2081V\u2081 = P\u2082V\u2082
''',
                '''
Use formula below:
\nP\u2081/T\u2081 = P\u2082/T\u2082
''',
                '''
Use formula below:
\nV\u2081/T\u2081 = V\u2082/T\u2082
''',
                '''
Use formula below:
\nP\u2081V\u2081 = P\u2082V\u2082
''',
                '''
Use formula below:
\nP\u2081/T\u2081 = P\u2082/T\u2082
''']
