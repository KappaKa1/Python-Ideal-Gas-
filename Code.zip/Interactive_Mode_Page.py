# Universal Variable and Function
Frame_List = []
Help_Title = "Interactive Mode Help"
Help_Message = '''
Welcome to the Interactive Mode Help.
Animation occupies the right section of the window, and the controls occupies the left.

To begin Animation:
Select a condition in the option menu located at the control section and all else would be settled.
To modify the variables, move the scale to your desired amount

- Press CTRL + 1 for Interactive Mode Page 
- Press CTRL + 2 for Graph Page
- Press CTRL + 3 for Quiz Page

- Press 'H' Key for HELP
- Press Spacebar to pause and resume animation
- Select a scale to move 
- Move scales using left and right arrow keys
- Press 'I' Key for information on Output variables

'''

def Get_Frame_List(): return Frame_List
def Get_Help_Title(): return Help_Title
def Get_Help_Message(): return Help_Message


# Main Purpose is to create the layout of the page when called
# Layout is Canvas at the right, Widgets at the left
# Will only contain the Design and call-ball functions
# Animation will be handled in a seperate file

from tkinter import messagebox
import tkinter as tk
import Animation as BA
import math as ma
import Main_Menu as MM


# Main Variables

# Variables that can be changed
Info_Title="Definitions, Symbols and Formulae"
Info_Message= '''
Density, \u03C1 is the mass m per unit volume V of a gas
    \n\t\u03C1= m/V\n \n 
    
Root Mean Square Speed (RMS) is the speed at which the gas molecules travels at
    \n\t√c̅ \u00B2=√(3RT/M)\n
    
Kinetic Energy (KE) is the energy of the molecules due to it's motion
    \n\tKE=(3nRT)/2\n
'''
Enabled_Scale_Colour = "#c9cbf1"
Disabled_Scale_Colour = "gray"

# Variables that are constant
Universal_Gas_Constant = 8.31
Number_of_Mole = 1
Variable_Index = {"Pressure":0, "Volume":1, "Temperature":2}
Law_Index = {"Boyles":1, "Charles":2, "Lussacs":3}
PV_CONSTANT = 10
VT_CONSTANT = 290
PT_CONSTANT = 290
Canvas_Height = 560
Canvas_Width = 630
KE_Min=60
RMS_Min=501
Density= 28.8
Pressure_per_Press = 0.1
Volume_per_Press = 0.1
Temperature_per_Press = 10
Universal_Gas_Constant = 8.31
Number_of_Mole = 1
Variable_Index = {"Pressure":0, "Volume":1, "Temperature":2}
Law_Index = {"Boyles":1, "Charles":2, "Lussacs":3}
PV_CONSTANT = 10
VT_CONSTANT = 290
PT_CONSTANT = 290
Canvas_Height = 560
Canvas_Width = 800
KE_Min=60
RMS_Min=501
Density= 28.8
Pressure_per_Press = 0.1
Volume_per_Press = 0.1
Temperature_per_Press = 10

# Range for Scales
P_Min = 1
P_Max = 10
V_Min = 1
V_Max = 10
T_Min = 290
T_Max = 2900

# Variables that only will be used once
First = True # Change

# Variables that changes during operation # Change
Interactive_Open = False # Change
Current_Law = 0 # Change
Pressed_P_Scale = False # Change
Pressed_V_Scale = False # Change
Pressed_T_Scale = False # Change


def Close_Interactive():
    global Interactive_Open
    Interactive_Open = False

def Reset_Values():# Change
    global Interactive_Open
    global Current_Law
    global Pressed_P_Scale
    global Pressed_V_Scale
    global Pressed_T_Scale

    Interactive_Open = True
    Current_Law = 0
    Pressed_P_Scale = False
    Pressed_V_Scale = False
    Pressed_T_Scale = False


# Interactive Mode Designs
def Interactive_Mode_Design(Window):
    global Frame_List
    global First # Change

    Reset_Values() # Change

    # Local Variables
    Scale_List = []

    # Convinience Functions
    def Pause(): # Change
        # Calls a command in Ball_Animation that changes the variable in Ball_Animation
        if Current_Law == 0: return

        BA.Stop_Animation()
        Pause_Picture.config(file='playbutton.gif')
        Resume_Button.config(command=Resume)
        for Scale in Scale_List:
            Scale.config(state=tk.DISABLED, bg=Disabled_Scale_Colour, relief=tk.FLAT)
        Condition_Menu.config(state=tk.DISABLED)

    def Resume(): # Change
        BA.Start_Animation()
        Pause_Picture.config(file='pausebutton.gif')
        Resume_Button.config(command=Pause)
        Reset_ALl_Scale()
        Constant = Menu_Display.get()[9:]
        Disable_Scale(Constant)
        if Pressed_P_Scale: Pressure_Scale.config(relief=tk.RAISED)
        if Pressed_V_Scale: Volume_Scale.config(relief=tk.RAISED)
        if Pressed_T_Scale: Temperature_Scale.config(relief=tk.RAISED)
        Condition_Menu.config(state=tk.NORMAL)


    # Functions Used in Key Binding # Change
    def Space_Pause(value=0): # Change
        if not Interactive_Open: return
        Resume_Button.invoke()

    def Reset_Bind(): # Change
        global Pressed_P_Scale
        global Pressed_V_Scale
        global Pressed_T_Scale
        Pressed_P_Scale = False
        Pressed_V_Scale = False
        Pressed_T_Scale = False

    def Reset_Relief(): # Change
        for Scale in Scale_List:
            Scale.config(relief=tk.FLAT)

    def Reset_Pressed(): # Change
        Reset_Bind()
        Reset_Relief()

    def Pressed_P(value=0): # Change
        global Pressed_P_Scale
        if not Interactive_Open or not BA.Ongoing_Animation: return
        if Current_Law == Law_Index["Charles"] or Current_Law == 0: return

        Reset_Pressed()
        Pressed_P_Scale = True
        Pressure_Scale.config(relief = tk.RAISED)

    def Pressed_V(value=0): # Change
        global Pressed_V_Scale
        if not Interactive_Open or not BA.Ongoing_Animation: return
        if Current_Law == Law_Index["Lussacs"] or Current_Law == 0: return

        Reset_Pressed()
        Pressed_V_Scale = True
        Volume_Scale.config(relief=tk.RAISED)

    def Pressed_T(value=0): # Change
        global Pressed_T_Scale
        if not Interactive_Open or not BA.Ongoing_Animation: return

        if Current_Law == Law_Index["Boyles"] or Current_Law == 0: return

        Reset_Pressed()
        Pressed_T_Scale = True
        Temperature_Scale.config(relief=tk.RAISED)

    def Increase_Scales_by_Key(value=0): # Change
        if not Interactive_Open: return

        if Pressed_P_Scale:
            Pressure = Pressure_Scale.get()
            Pressure_Scale.set(Pressure + Pressure_per_Press)
        if Pressed_V_Scale:
            Volume = Volume_Scale.get()
            Volume_Scale.set(Volume + Volume_per_Press)
        if Pressed_T_Scale:
            Temperature = Temperature_Scale.get()
            Temperature_Scale.set(Temperature + Temperature_per_Press)

    def Decrease_Scales_by_Key(value=0): # Change
        if not Interactive_Open: return

        if Pressed_P_Scale:
            Pressure = Pressure_Scale.get()
            Pressure_Scale.set(Pressure - Pressure_per_Press)
        if Pressed_V_Scale:
            Volume = Volume_Scale.get()
            Volume_Scale.set(Volume - Volume_per_Press)
        if Pressed_T_Scale:
            Temperature = Temperature_Scale.get()
            Temperature_Scale.set(Temperature - Temperature_per_Press)

    # Function Used in Call-Back Functions

    # Functions used when the condition menu is modified.
    # Change
    def Reset_ALl_Scale():
        for Scale in Scale_List:
            Scale.config(state=tk.NORMAL, bg=Enabled_Scale_Colour)

    def Disable_Scale(Constant):
        for Variable in Variable_Index:
            if Constant == Variable:
                Index = Variable_Index[Variable]
                Scale_List[Index].config(state=tk.DISABLED, bg=Disabled_Scale_Colour)
                break

    def Determine_Law(Constant):
        global Current_Law
        if Constant == "Pressure": Current_Law = Law_Index["Charles"]
        if Constant == "Volume": Current_Law = Law_Index["Lussacs"]
        if Constant == "Temperature": Current_Law = Law_Index["Boyles"]

    def Reposition_Scale():
        if Current_Law == Law_Index["Boyles"]:
            Pressure_Scale.set(P_Min)
            Volume_Scale.set(V_Max)
        if Current_Law == Law_Index["Charles"]:
            Volume_Scale.set(V_Min)
            Temperature_Scale.set(T_Min)
        if Current_Law == Law_Index["Lussacs"]:
            Pressure_Scale.set(P_Min)
            Temperature_Scale.set(T_Min)

    # Functions used in scale movements.
    # These includes balancing of other variable's scales and values
    # when user inputs and also calculations to obtain certain quantities
    def P_Scale_Movement(value):
        if Current_Law == Law_Index["Boyles"]:
            Volume = PV_CONSTANT/value
            Volume_Scale.set(Volume)
        if Current_Law == Law_Index["Lussacs"]:
            Temperature = value * PT_CONSTANT
            Temperature_Scale.set(Temperature)

    def V_Scale_Movement(value):
        if Current_Law == Law_Index["Boyles"]:
            Pressure = PV_CONSTANT/value
            Pressure_Scale.set(Pressure)
        if Current_Law == Law_Index["Charles"]:
            Temperature = value * VT_CONSTANT
            Temperature_Scale.set(Temperature)

    def T_Scale_Movement(value):
        if Current_Law == Law_Index["Charles"]:
            Volume = value/VT_CONSTANT
            Volume_Scale.set(Volume)
        if Current_Law == Law_Index["Lussacs"]:
            Pressure = value / PT_CONSTANT
            Pressure_Scale.set(Pressure)

    # Calculations of other quantities
    def Calculate_RMS_T(value):
        # use rms= root(3pV/m) or root(3RT/M) to calculate
        # converts the P values and use m as 28.8*10-3kg
        rms = int(ma.sqrt((3 * Universal_Gas_Constant * value) / 0.0288))
        RMS_String.set(str(rms) +' m/s')


    def Calculate_Density(value):
        # use density=3p/RMS to calculate
        # Use m as 28.8*10-3kg
        density= int(28.8 / value)
        Density_String.set(str(density) +' g/m^3')


    def Calculate_KE(value):
        # use KE= 3nRT/2 to calculate
        # converts the P values and use m as 28.8*10-3kg
        KE= int((3 * Number_of_Mole * Universal_Gas_Constant * value) / 2)
        KE_String.set(str(KE) +' J')


    # Call-Back Functions
    def Cond_Menu_Modification(Condition):
        Resume_Button.config(state=tk.NORMAL)
        Reset_ALl_Scale()
        Constant = Condition[9:]
        Disable_Scale(Constant)
        Determine_Law(Constant)
        Reposition_Scale()
        Reset_Pressed() # Change


    def Pressure_Modification(value):
        Pressure_String.set(value + ' atm')
        Pressure = float(value)
        P_Scale_Movement(Pressure)
        Change_in_Pressure = Pressure - 1
        BA.Pressure_Animation(Display_Board, Change_in_Pressure)


    def Volume_Modification(value):
        Volume_String.set(value + ' m^3')
        Volume = float(value)
        V_Scale_Movement(Volume)
        Change_in_Volume = Volume - V_Min
        BA.Volume_Animation(Display_Board, Change_in_Volume)
        Calculate_Density(Volume)


    def Temperature_Modification(value):
        Temperature_String.set(value + ' K')
        Temperature = float(value)
        T_Scale_Movement(Temperature)
        Change_in_Temp = Temperature - T_Min
        BA.Temperature_Animation(Display_Board, Change_in_Temp)
        Calculate_RMS_T(Temperature)
        Calculate_KE(Temperature)

    #function for info_button
    def Show_Info(value=0):
        if not Interactive_Open: return
        messagebox.showinfo(Info_Title,Info_Message)
        info_pic.config(file='Info_pic.gif')


    # Design of Page
    # Design of the Canvas Section
    Mid_Frame = tk.Frame(Window, highlightbackground='black', highlightthickness=2, bg='#c9cbf1')
    Mid_Frame.place(x=25,y=75, bordermode=tk.OUTSIDE)
    Display_Board = tk.Canvas(Mid_Frame,width= Canvas_Width,height= Canvas_Height, bg='#c9cbf1',bd=0, highlightthickness=0)
    Display_Board.grid(row=0,column=0)

    #Bluetooth Image and Battery Image
    # Topicon_Picture= tk.PhotoImage(file='battery.gif')
    # Topicon=tk.Canvas(Display_Board, width=60,height=30,bg='orange',bd=0,highlightthickness=0)
    # Topicon.place(x=680,y=110)
    # Topicon.create_image(40,20, anchor=tk.S, image=Topicon_Picture)
                           

    #Images for pause and play buttons
    Pause_Picture= tk.PhotoImage(file='pausebutton.gif')
    Play_Picture= tk.PhotoImage(file='playbutton.gif')
    Resume_Button = tk.Button(Display_Board, image=Pause_Picture, command=Pause, state=tk.DISABLED, bd=0, highlightthickness=0)
    Resume_Button.place(x=400,y=520)


    # Design of the Display Table
    Pressure_String = tk.StringVar(value = str(P_Min) + " atm")
    Volume_String = tk.StringVar(value = str(V_Min) + " m\u00B3")
    Temperature_String = tk.StringVar(value = str(T_Min) + " K")
    Left_Frame = tk.Frame(Window, highlightbackground='black', highlightthickness=2, width=300,bg='#c9cbf1')
    Left_Frame.place(x=870,y=80)
    Input_Label = tk.Label(Left_Frame, text='Input', font=('Georgia',18), padx=10, pady=5,bg='#c9cbf1')
    Input_Label.grid(row=0, column=0)
    Display_Frame = tk.Frame(Left_Frame, highlightbackground='black', highlightthickness=2,bg='#cae6f2')
    Display_Frame.grid(row=1,column=0)
    tk.Label(Display_Frame, text='Pressure',bg='#cae6f2').grid(row=0, column=0)
    tk.Label(Display_Frame, textvariable=Pressure_String, width=12,bg='#cae6f2').grid(row=0,column=1)
    tk.Label(Display_Frame, text='Volume',bg='#cae6f2').grid(row=1, column=0)
    tk.Label(Display_Frame, textvariable=Volume_String, width=12,bg='#cae6f2').grid(row=1,column=1)
    tk.Label(Display_Frame, text='Temperature',bg='#cae6f2').grid(row=2,column=0)
    tk.Label(Display_Frame, textvariable=Temperature_String, width=12,bg='#cae6f2').grid(row=2,column=1)
    tk.Label(Display_Frame, text='Mole',bg='#cae6f2').grid(row=3,column=0)
    tk.Label(Display_Frame, text='1 mol', width=12,bg='#cae6f2').grid(row=3,column=1)
    tk.Label(Display_Frame, text='Molar Mass',bg='#cae6f2').grid(row=4,column=0)
    tk.Label(Display_Frame, text='28.8 g/mol', width=12,bg='#cae6f2').grid(row=4,column=1)


    # Design of control section
    Option_List = ["Constant Pressure", "Constant Volume", "Constant Temperature"]
    Menu_Display = tk.StringVar()
    Menu_Display.set("Please select a condition")
    Condition_Menu = tk.OptionMenu(Left_Frame, Menu_Display, *Option_List, command= Cond_Menu_Modification)
    Condition_Menu.config(bg='#cae6f2', activebackground='#cae6f2')
    Condition_Menu.config(width=20)
    Condition_Menu.grid(row=2, column=0, padx=50, pady=35)

    Pressure_Scale = tk.Scale(Left_Frame, from_=P_Min, to=P_Max, label="Pressure", state= tk.DISABLED,showvalue=0,
                            orient= tk.HORIZONTAL, length=150, resolution=0.1, command = Pressure_Modification,bg='gray')
    Pressure_Scale.grid(row=3, column=0)
    
    Volume_Scale = tk.Scale(Left_Frame, from_=V_Min, to=V_Max, label="Volume", state= tk.DISABLED,showvalue=0,
                            orient= tk.HORIZONTAL, length=150, resolution=0.1, command = Volume_Modification,bg='gray')
    Volume_Scale.grid(row=4, column=0)
    Temperature_Scale = tk.Scale(Left_Frame, from_=T_Min, to=T_Max, label= "Temperature", state= tk.DISABLED, showvalue=0,
                            orient= tk.HORIZONTAL, length=150, resolution=10, command = Temperature_Modification,bg='gray')
    Temperature_Scale.grid(row=5, column=0)
    

    # Design of the Output Display Table
    Density_String = tk.StringVar(value=str(Density) + " g/m\u00B3")
    KE_String = tk.StringVar(value=str(KE_Min) + " J")
    RMS_String = tk.StringVar(value=str(RMS_Min) + " m/s")
    Output_Label = tk.Label(Left_Frame, text='\nOutput', font=('Georgia',18), padx=5,bg='#c9cbf1')
    Output_Label.grid(row=6, column=0)


    #Image for info button
    info_pic=tk.PhotoImage(file='Info_pic.gif')
    Info_Button= tk.Button(Left_Frame, image=info_pic, command= Show_Info).place(x=190,y=415)
    Output_Frame = tk.Frame(Left_Frame, highlightbackground='black', highlightthickness=2, padx=3, pady=10,width=250,bg='#cae6f2')
    Output_Frame.grid(row=7, column=0)
    tk.Label(Output_Frame, text='Density' ,bg='#cae6f2').grid(row=0, column=0)
    tk.Label(Output_Frame, textvariable=Density_String, width=12,bg='#cae6f2').grid(row=0, column=1)
    tk.Label(Output_Frame, text='Root Mean Square Speed',bg='#cae6f2').grid(row=1, column=0)
    tk.Label(Output_Frame, textvariable=RMS_String, width=12,bg='#cae6f2').grid(row=1, column=1)
    tk.Label(Output_Frame, text='Kinetic Energy',bg='#cae6f2').grid(row=2, column=0)
    tk.Label(Output_Frame, textvariable=KE_String, width=12,bg='#cae6f2').grid(row=2, column=1)

    
    Space_Frame=tk.Frame(Left_Frame, pady=2,bg='#c9cbf1')
    Space_Frame.grid(row=8, column=0)
    tk.Label(Space_Frame,text='',bg='#c9cbf1').pack(pady=1)

    Scale_List = [Pressure_Scale, Volume_Scale, Temperature_Scale]

    # Key Bindings
    Window.bind("<space>", Space_Pause)
    Window.bind("<Right>", Increase_Scales_by_Key)
    Window.bind("<Left>", Decrease_Scales_by_Key)
    Window.bind("<Key-i>", Show_Info)
    Pressure_Scale.bind("<Button-1>", Pressed_P)
    Volume_Scale.bind("<Button-1>", Pressed_V)
    Temperature_Scale.bind("<Button-1>", Pressed_T)

    # Animation
    BA.Canvas_Layout(Display_Board)
    BA.Animation_For_Ball(Window, Display_Board)

    #Store Frame Used
    Frame_List = [Left_Frame, Mid_Frame]

    # Introduction
    if First: # Change
        messagebox.showinfo(Help_Title, Help_Message)
        First = False
