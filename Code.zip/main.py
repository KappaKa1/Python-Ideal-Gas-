# Main Module Code
import tkinter as tk
import Main_Menu as MM
import random as Rand

# Introduction Page
Ball_in_Frame = []
Movement_of_Ball = []
End = False 
Window_Length = 1100
Window_Height = 650
Radius_of_Ball = 90
Time_per_Ball = 50
Num_of_Ball = 5
Intro_Message = "Press Enter To Begin!"
Main_Window = tk.Tk()
Main_Window.geometry('900x600')
Main_Window.minsize(1180,650)
Main_Window.maxsize(1180,650)
Main_Window.configure(bg='#cae6f2')
Main_Window.title('IDEAL GASES')


def Begin(value=0):
    global End 
    if End: return 

    End = True 
    Board.destroy()
    Main_Window.geometry("1180x650")
    Main_Window.configure(bg='#cae6f2')
    MM.Main_Menu(Main_Window)
    


def Main_Intro_Animation(): 

    def Initiate_Ball():
        # Creates the First few balls for the start of the animation
        # Num of Ball can be changed

        for times in range(Num_of_Ball):
            X1 = Rand.randint(0, 900 - Radius_of_Ball)
            Y1 = Rand.randint(0, 600 - Radius_of_Ball)
            X2 = X1 + Radius_of_Ball
            Y2 = Y1 + Radius_of_Ball
            Ball = Board.create_oval(X1, Y1, X2, Y2, fill="#d4f9d2")
            Ball_in_Frame.append(Ball)
            Movement_of_Ball.append(Rand.randint(10, 15))

    def Create_Random_Ball():
        # Ball is created from bottom
        # Only happens when a ball exit the canvas

        X1 = Rand.randint(0, 900 - Radius_of_Ball)
        Y1 = Rand.randint(600, 600+Radius_of_Ball)
        X2 = X1 + Radius_of_Ball
        Y2 = Y1 + Radius_of_Ball
        Ball = Board.create_oval(X1, Y1, X2, Y2, fill="#d4f9d2")
        Ball_in_Frame.append(Ball)
        Movement_of_Ball.append(Rand.randint(10,15))

    def Remove_Ball():
        # Checks if Ball is out of Canvas
        # Removes Ball from the list and Canvas
        # Removes its movement

        for Index in range(len(Ball_in_Frame)):
            Ball = Ball_in_Frame[Index]
            Coords = Board.coords(Ball)
            if Coords[3] < 0:
                Ball_in_Frame.remove(Ball)
                Movement_of_Ball.remove(Movement_of_Ball[Index])
                Board.delete(Ball)
                Create_Random_Ball()

    def Move_Ball():
        # Ball only moves upwards

        global Ball_in_Frame
        for Index in range(len(Ball_in_Frame)):
            Ball = Ball_in_Frame[Index]
            Movement = Movement_of_Ball[Index]
            Ball_Coords = Board.coords(Ball)
            Board.delete(Ball)
            New_Ball = Board.create_oval(Ball_Coords[0], Ball_Coords[1] - Movement, Ball_Coords[2], Ball_Coords[3] - Movement, fill='#c9cbf1')
            Ball_in_Frame[Index] = New_Ball # Replaces old ball
            Board.update()

    def Animate_Intro():
        Move_Ball()
        Remove_Ball()
        Main_Window.after(Time_per_Ball, Animate_Intro)

    Initiate_Ball()
    Animate_Intro()



Board = tk.Canvas(Main_Window, height=650, width = 1180, bg='#cae6f2',bd=0, highlightthickness=0)
Board.pack()

# Intro Message # Change
intro_msg =Board.create_text(575,200, text='Welcome to IDEAL GASES!', font=('Segoe Script' ,40 ,'bold',),fill='#569e51')
intro_msg2 =Board.create_text(600,275, text='Press Enter To Begin!', font=('Segoe Script' ,28 ,'bold'),fill='#569e51')

# Binding of keys # Change
Main_Window.bind_all("<Return>", Begin) # Change

Main_Intro_Animation() # Change
tk.mainloop()
