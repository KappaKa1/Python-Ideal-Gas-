# Universal Variable and function
Frame_List = []
Help_Title = "Graphs Help"
Help_Message =  '''
Welcome to the Graphs Help.
To display a graph on your window, select one of the three buttons presented beside the graph canvas.

For more info on the specific graph, please press the Definition button located beside the graph.

    - Press CTRL + 1 for Interactive Mode Page 
    - Press CTRL + 2 for Graph Page
    - Press CTRL + 3 for Quiz Page

    -Press the 'H' Key for HELP
    -Press the 'G' Key for DEFINITIONS
    -Press the 'B' Key for Boyle's Law 
    -Press the 'C' Key for Charle's Law
    -Press the 'V' Key for Constant Volume Law

'''


def Get_Frame_List(): return Frame_List
def Get_Help_Title(): return Help_Title
def Get_Help_Message(): return Help_Message


# Main Purpose is to create the layout the page when called
# Layous is: Buttons for Graphs right below Main menu, Graphs at bottom right and
#            Guide Button at bottom left
# Graph design will be in a seperate file

import tkinter as tk
from tkinter import messagebox
import Graphs_Creation as GC
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2Tk


# Main Variables and should not be touched
Canvas_Height = 400
Canvas_Width = 500
Guide_Title = "Guide of the day"
Guide_Content = "Try looking in the mirror today! Be careful, you might spot a loser."
Boyles_Law_Title = "Definition of Boyle\'s Law"
Boyles_Law_Def =''' 
Boyle's Law states that in constant temperature, 
the pressure within the container is inversely proportional 
to its volume.
P\u2081V\u2081=P\u2082V\u2082
'''
Charles_Law_Title = "Definition of Charle\'s Law"
Charles_Law_Def = '''
Charle's Law states that in constant pressure, the volume
of the container is directly proportional to the temperature  
of the particles.
V\u2081/T\u2081 = V\u2082/T\u2082
'''
Gay_Lussacs_Law_Title = "Definition of Gay Lussaac\'s Law"
Gay_Lussacs_Law_Def = '''
Gay Lussaac\'s Law states that in constant volume, the pressure
in the container is directly proportional to the temperature
of the particles.
P\u2081/T\u2081 = P\u2082/T\u2082
'''

# Variable that will only be used once
First = True

# Variables that will be changed during operation # Change
Graph_Open = False 
Guide_Open = False
Boyle_Open = False
Charles_Open = False
Lussacs_Open = False


def Close_Graph(): 
    global Graph_Open
    Graph_Open = False


def Reset():# Change
    global Graph_Open
    global Guide_Open
    global Guide_Title
    global Guide_Content
    global Boyle_Open
    global Charles_Open
    global Lussacs_Open


    Graph_Open = True
    Guide_Open = False
    Guide_Title = "Guide of the day"
    Guide_Content = "Try looking in the mirror today! Be careful, you might spot a loser."
    Boyle_Open = False
    Charles_Open = False
    Lussacs_Open = False

def Graphs_Design(Window):
    global Frame_List
    global First
    # Change

    Reset()# Change


    # Functions used in callback-functions
    def Reset_Button():
        Boyle_Button.config(state = tk.NORMAL)
        Charle_Button.config(state = tk.NORMAL)
        Const_Vol_Button.config(state = tk.NORMAL)
        Guide_Button.config(state=tk.NORMAL)
        


    # Functions used in Binding
    def Reset_Open():
        global Guide_Open
        global Boyle_Open
        global Charles_Open
        global Lussacs_Open
        
        Guide_Open = False
        Boyle_Open = False
        Charles_Open = False
        Lussacs_Open = False
    


    # Call-Back Functions
    def Cancel(top):
        top.destroy()
        
    def Guide_Message(Guide_Title, Guide_Content):
        Guide_Window= tk.Toplevel()
        Guide_Window.geometry("470x150")
        Guide_Window.maxsize(470,150)
        Guide_Window.minsize(470,150)
        Guide_Window.title(Guide_Title)
        Guide_Image_Label= tk.Label(Guide_Window, image=Guide_Image, text=Guide_Content, compound=tk.LEFT)
        Guide_Image_Label.place(x=0, y=0)
        Guide_Content_Label = tk.Label(Guide_Window, text = Guide_Content, anchor=tk.E,bg='white')
        Guide_Content_Label.place(x=140, y=0)
        Guide_Ok_Button=tk.Button(Guide_Window, text='OK', command=Guide_Window.destroy,height=1,width=10)
        Guide_Ok_Button.place(x=235, y=110)
        Guide_Ok_Button.focus()
        Guide_Ok_Button.bind("<Return>", lambda event = None:Cancel(Guide_Window))
        
    def Guide_Pop_Up(value=0):
        if not Guide_Open: return 

        Guide_Message(Guide_Title, Guide_Content)

    # Keep tracks if their respective graph is open to prevent spamming
    # These functions Changes the Guides title and Contents, Plots its graph and
    # disables the button clicked
    def Boyles_Law(value=0):
        global Guide_Open
        global Guide_Title
        global Guide_Content
        global Boyle_Open

        # Bindings
        if Boyle_Open or not Graph_Open: return
        Reset_Open()
        Guide_Open = True
        Boyle_Open = True

        # Buttons
        Reset_Button()
        Boyle_Button.config(state=tk.DISABLED)
        
       

        # Body
        Guide_Title = Boyles_Law_Title
        Guide_Content = Boyles_Law_Def
        Guide_Image.config(file="boylepic.gif") 
        GC.Plot_Boyle(Canvas_Frame)


    def Charles_Law(value=0):
        global Guide_Open
        global Guide_Title
        global Guide_Content
        global Charles_Open

        # Bindings
        if Charles_Open or not Graph_Open: return
        Reset_Open()
        Guide_Open = True
        Charles_Open = True

        # Buttons
        Reset_Button()
        Charle_Button.config(state=tk.DISABLED)
        

        # Body
        Guide_Title = Charles_Law_Title
        Guide_Content = Charles_Law_Def
        Guide_Image.config(file="charlespic.gif") 
        GC.Plot_Charles(Canvas_Frame)


    def Gay_Lussacs_Law(value=0):
        global Guide_Open
        global Guide_Title
        global Guide_Content
        global Lussacs_Open

        # Bindings
        if Lussacs_Open or not Graph_Open: return
        Reset_Open()
        Guide_Open = True        
        Lussacs_Open = True

        # Button
        Reset_Button()
        Const_Vol_Button.config(state=tk.DISABLED)
       
        # Body
        Guide_Title = Gay_Lussacs_Law_Title
        Guide_Content = Gay_Lussacs_Law_Def
        Guide_Image.config(file="lusaacpic.gif")
        GC.Plot_Const_Volume(Canvas_Frame)

    



    # Button Design for accessing different graphs
    Button_Frame = tk.Frame(Window,relief="solid", bg='#cae6f2',)#CHANGED JON
    Button_Frame.place (x=825, y=200)
    Boyle_Button = tk.Button(Button_Frame,text='Boyle\'s Law',
                             command=Boyles_Law, bg="#c9cbf1",
                             font=("Georgia",11), padx = 4, pady = 2, width=20)#CHANGED JON
    Boyle_Button.grid(row=1,column=1)
    Charle_Button = tk.Button(Button_Frame,text='Charle\'s Law',
                              command=Charles_Law,bg="#c9cbf1",
                              font=("Georgia",11), padx = 4, pady = 2,width=20)
    Charle_Button.grid(row=2,column=1)
    Const_Vol_Button = tk.Button(Button_Frame,text='Constant Volume Law',
                                 command=Gay_Lussacs_Law, bg="#c9cbf1",
                                 font=("Georgia",11), padx = 4, pady = 2)
    Const_Vol_Button.grid(row=3,column=1,sticky=tk.EW)

    # Canvas Design to display the graphs
    Canvas_Frame = tk.Frame(Window)
    Canvas_Frame.place (x=50, y=75)
    Graph_Fig = plt.Figure(figsize=(7.5, 5.5), dpi=100)
    Plotter = Graph_Fig.add_subplot(111)
    Plotter.set_xlim([0,13])
    Plotter.set_ylim([0,13])
    Board = FigureCanvasTkAgg(Graph_Fig, master=Canvas_Frame)
    Plotter.grid(True)
    Board.get_tk_widget().grid(row=2, column=0)

    #Guide Image that changes during operation
    Guide_Image= tk.PhotoImage(file="randompic.gif")


    # Guide Button Design to provide guidance
    Left_Frame = tk.Frame(Window,width=200,height=200,borderwidth=2,relief="solid")
    Left_Frame.place (x = 870, y=400)
    Guide_Button = tk.Button(Left_Frame, text='DEFINITION', command=Guide_Pop_Up, font=("Georgia",11), bg="#c9cbf1", activebackground="#c9cbf1", state=tk.DISABLED)#CHANGED JON
    Guide_Button.pack(side=tk.RIGHT)
    
    # Binding of Keys
    Window.bind("<Key-g>", Guide_Pop_Up) # Change
    Window.bind("<Key-b>", Boyles_Law)
    Window.bind("<Key-c>", Charles_Law)
    Window.bind("<Key-v>", Gay_Lussacs_Law)

    # Save Frames used into a list # Change
    Frame_List = [Button_Frame, Canvas_Frame, Left_Frame]

    # Introduction
    if First:  # Change
        messagebox.showinfo(Help_Title, Help_Message)
        First = False
